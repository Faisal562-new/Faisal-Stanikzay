param([string]$Path, [string]$Content)`n[System.IO.File]::WriteAllText($Path, $Content, [System.Text.Encoding]::UTF8)`nWrite-Host "Written: $($Path)"
