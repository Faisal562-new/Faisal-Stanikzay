<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CourseController extends Controller
{
    public function index(Request $request)
    {
        return $this->dashboard($request);
    }

    public function store(Request $request)
    {
        $data = $this->validatedData($request);
        $data['user_id'] = $request->user()->id;
        Course::create($data);

        return redirect()->route('dashboard')
            ->with('success', 'Course registered.');
    }

    public function show(Request $request, int $course)
    {
        $record = $this->ownedCourse($request, $course);

        return $this->dashboard($request, null, $record);
    }

    public function edit(Request $request, int $course)
    {
        $record = $this->ownedCourse($request, $course);

        return $this->dashboard($request, $record);
    }

    public function update(Request $request, int $course)
    {
        $record = $this->ownedCourse($request, $course);
        $data = $this->validatedData($request, $record);
        $record->update($data);

        return redirect()->route('dashboard')
            ->with('success', 'Course updated.');
    }

    public function destroy(Request $request, int $course)
    {
        $record = $this->ownedCourse($request, $course);
        $record->delete();

        return redirect()->route('dashboard')
            ->with('success', 'Course deleted.');
    }

    private function ownedCourse(Request $request, int $course)
    {
        return Course::where('user_id', $request->user()->id)
            ->findOrFail($course);
    }

    private function validatedData(Request $request, ?Course $record = null)
    {
        $courseCode = strtoupper(trim((string) $request->input('course_code', '')));

        $rules = [
            'course_code' => [
                'required',
                'string',
                'max:20',
                Rule::unique('courses', 'course_code')
                    ->where('user_id', $request->user()->id),
            ],
            'course_name' => ['required', 'string', 'max:150'],
            'credit_hours' => ['required', 'integer', 'between:1,6'],
            'semester' => ['required', 'string', Rule::in(['Spring 2026', 'Fall 2026'])],
        ];

        if ($record) {
            $rules['course_code'][] = Rule::ignore($record->id);
        }

        $request->merge(['course_code' => $courseCode]);

        return $request->validate($rules);
    }
}
