<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Course Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{ asset('css/dashboard.css') }}" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navigation bar -->
<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="{{ route('dashboard') }}">
            Course Dashboard
        </a>

        <form method="POST"
              action="{{ route('logout') }}"
              class="mb-0">
            @csrf
            <button type="submit" class="btn btn-outline-light">
                Logout
            </button>
        </form>
    </div>
</nav>

<main class="container py-4">

    <h1 class="h3 mb-2">Dashboard</h1>

    <p class="text-secondary mb-4">
        Welcome, <strong>{{ auth()->user()->name }}</strong>!
        Register a course and view your registered courses below.
    </p>

    <!-- Success message -->
    @if (session('success'))
        <div class="alert alert-success" role="alert">
            {{ session('success') }}
        </div>
    @endif

    <!-- Registration form -->
    <section class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <h2 class="h5 mb-0">Register / Edit Course</h2>
        </div>

        <div class="card-body">
            @include('courses.form')
        </div>
    </section>

    <!-- Registered courses table -->
    <section class="card shadow-sm mb-4">
        <div class="card-header bg-secondary text-white">
            <h2 class="h5 mb-0">My Registered Courses</h2>
        </div>

        <div class="card-body">
            @include('courses.table')
        </div>
    </section>

    <!-- Course details card (viewing state) -->
    @if ($viewing)
        <section class="card shadow-sm mb-4">
            <div class="card-header bg-info text-white">
                <h2 class="h5 mb-0">Course Details</h2>
            </div>
            <div class="card-body">
                @include('courses.details')
            </div>
        </section>
    @endif

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
