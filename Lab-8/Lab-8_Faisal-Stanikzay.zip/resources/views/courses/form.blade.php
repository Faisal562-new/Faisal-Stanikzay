<form method="POST"
      action="{{ isset($editing) ? route('courses.update', $editing->id) : route('courses.store') }}"
      autocomplete="off">

    @csrf
    @if (isset($editing))
        @method('PUT')
    @endif

    <div class="row g-3">

        <!-- Course code -->
        <div class="col-md-6">
            <label for="course_code" class="form-label">Course Code</label>
            <input
                type="text"
                id="course_code"
                name="course_code"
                class="form-control @error('course_code') is-invalid @enderror"
                value="{{ old('course_code', isset($editing) ? $editing->course_code : '') }}"
                maxlength="20">
            @error('course_code')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Course name -->
        <div class="col-md-6">
            <label for="course_name" class="form-label">Course Name</label>
            <input
                type="text"
                id="course_name"
                name="course_name"
                class="form-control @error('course_name') is-invalid @enderror"
                value="{{ old('course_name', isset($editing) ? $editing->course_name : '') }}"
                maxlength="150"
                required>
            @error('course_name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Credit hours -->
        <div class="col-md-6">
            <label for="credit_hours" class="form-label">Credit Hours</label>
            <input
                type="number"
                id="credit_hours"
                name="credit_hours"
                class="form-control @error('credit_hours') is-invalid @enderror"
                value="{{ old('credit_hours', isset($editing) ? $editing->credit_hours : '') }}"
                min="1"
                max="6"
                required>
            @error('credit_hours')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Semester -->
        <div class="col-md-6">
            <label for="semester" class="form-label">Semester</label>
            <select
                id="semester"
                name="semester"
                class="form-select @error('semester') is-invalid @enderror"
                required>
                <option value="">Select semester</option>
                <option value="Spring 2026"
                    {{ old('semester', isset($editing) ? $editing->semester : '') === 'Spring 2026' ? 'selected' : '' }}>
                    Spring 2026
                </option>
                <option value="Fall 2026"
                    {{ old('semester', isset($editing) ? $editing->semester : '') === 'Fall 2026' ? 'selected' : '' }}>
                    Fall 2026
                </option>
            </select>
            @error('semester')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <!-- Actions -->
        <div class="col-12">
            @if (isset($editing))
                <button type="submit" class="btn btn-success me-2">
                    Save Changes
                </button>
                <a href="{{ route('dashboard') }}" class="btn btn-outline-secondary">
                    Cancel
                </a>
            @else
                <button type="submit" class="btn btn-primary">
                    Register / Save
                </button>
            @endif
        </div>

    </div>
</form>
