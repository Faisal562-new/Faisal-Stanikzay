<div class="row g-3">
    <div class="col-md-4">
        <label class="form-label fw-bold">Course Code</label>
        <p class="form-control-plaintext">{{ $viewing->course_code }}</p>
    </div>
    <div class="col-md-4">
        <label class="form-label fw-bold">Course Name</label>
        <p class="form-control-plaintext">{{ $viewing->course_name }}</p>
    </div>
    <div class="col-md-4">
        <label class="form-label fw-bold">Credits</label>
        <p class="form-control-plaintext">{{ $viewing->credit_hours }} / {{ $viewing->semester }}</p>
    </div>
</div>
