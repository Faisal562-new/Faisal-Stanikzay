<table class="table table-hover">
    <thead>
        <tr>
            <th style="width: 15%;">Code</th>
            <th style="width: 35%;">Course Name</th>
            <th style="width: 15%;">Credits</th>
            <th style="width: 20%;">Semester</th>
            <th style="width: 15%;">Actions</th>
        </tr>
    </thead>
    <tbody>
        @forelse ($courses as $course)
            <tr class="align-middle {{ $editing && $editing->id === $course->id ? 'table-warning' : '' }}">
                <td>{{ $course->course_code }}</td>
                <td>{{ $course->course_name }}</td>
                <td>{{ $course->credit_hours }}</td>
                <td>{{ $course->semester }}</td>
                <td class="w-25">
                    <div class="btn-group w-100">
                        <a href="{{ route('courses.show', $course->id) }}"
                           class="btn btn-sm btn-info w-100">
                            View
                        </a>
                        <a href="{{ route('courses.edit', $course->id) }}"
                           class="btn btn-sm btn-warning w-100">
                            Edit
                        </a>
                        <form method="POST"
                              action="{{ route('courses.destroy', $course->id) }}"
                              class="d-inline"
                              onsubmit="return confirm('Delete this course?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger w-100">
                                Delete
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="5" class="text-center text-muted py-4">
                    No courses registered yet.
                </td>
            </tr>
        @endforelse
    </tbody>
</table>
